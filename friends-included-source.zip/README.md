# Friends Included Finance

Financial workflow project for the Day 4 homework. Supabase is the source of truth; the website, Telegram bot, and Google Sheets are connected to it.

## Local start

1. Copy `.env.example` to `.env.local` and fill in the values.
2. Run the SQL migration in `supabase/migrations/001_initial_schema.sql` in the Supabase SQL Editor.
3. Install packages with `pnpm install` and start with `pnpm dev`.

## Environment variables

See `.env.example`. Keep all server-only values out of the browser and GitHub.

## Remaining connection steps

1. Create the Telegram bot and save its token in Vercel.
2. Create the Google service account, enable Sheets API, share the Sheet with its email, and add the private key to Vercel.
3. Add the Supabase URL, publishable key and secret key to Vercel.
4. Set the Telegram webhook to `/api/telegram` after deployment.
