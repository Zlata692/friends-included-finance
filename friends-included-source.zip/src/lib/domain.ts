export type Employee = "Svetlana" | "Richard" | "Anastasia" | "Jean-Claude" | "Kevin";
export type SaleStatus = "Pending approval" | "Approved";
export type ExpenseStatus = "Awaiting allocation" | "Allocated" | "Company overhead";

export const employees: Employee[] = ["Svetlana", "Richard", "Anastasia", "Jean-Claude", "Kevin"];
export const salespeople: Employee[] = ["Richard", "Anastasia", "Jean-Claude"];

export function canCreateSale(role: Employee) { return salespeople.includes(role); }
export function canCreateExpense(role: Employee) { return role === "Kevin"; }
export function canApprove(role: Employee) { return role === "Svetlana"; }

export function validateSplit(split: number[]) {
  return split.length === 3 && split.every((value) => Number.isFinite(value) && value >= 0 && value <= 100) && split.reduce((total, value) => total + value, 0) === 100;
}

export function commissionAmounts(amount: number, split: [number, number, number]) {
  const pool = Math.round(amount * 0.1 * 100) / 100;
  const values = split.map((share) => Math.round(pool * share) / 100);
  const remainder = Math.round((pool - values.reduce((a, b) => a + b, 0)) * 100) / 100;
  const max = Math.max(...split);
  const recipient = split.findIndex((value) => value === max);
  values[recipient] = Math.round((values[recipient] + remainder) * 100) / 100;
  return { pool, values };
}
