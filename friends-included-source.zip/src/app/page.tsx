"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import { Employee, canCreateExpense, canCreateSale, employees, validateSplit } from "@/lib/domain";

type RecordItem = { reference:string; kind:"Sale"|"Expense"; title:string; amount:number; status:string; };
const initialRecords: RecordItem[] = [
  { reference:"S05", kind:"Sale", title:"Mia Brooks · Project B", amount:600, status:"Pending approval" },
  { reference:"E07", kind:"Expense", title:"Emergency replacement clothing", amount:140, status:"Awaiting allocation" },
];
type Dashboard = { projectA:{result:number}; projectB:{result:number}; company:number; commission:Record<string,number>; records:RecordItem[] };

export default function Home() {
  const [role, setRole] = useState<Employee>("Svetlana");
  const [records, setRecords] = useState(initialRecords);
  const [dashboard, setDashboard] = useState<Dashboard | null>(null);
  const [message, setMessage] = useState("");
  const [split, setSplit] = useState([50,30,20]);
  const canSubmitSale = canCreateSale(role);
  const canSubmitExpense = canCreateExpense(role);
  const splitValid = useMemo(() => validateSplit(split), [split]);

  async function refreshDashboard() {
    const response = await fetch("/api/dashboard");
    if (response.ok) { const next = await response.json() as Dashboard; setDashboard(next); setRecords(next.records); }
  }
  useEffect(() => { refreshDashboard(); }, []);

  async function submitSale(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!canSubmitSale || !splitValid) return;
    const form = new FormData(event.currentTarget);
    const reference = String(form.get("reference")).trim().toUpperCase();
    const amount = Number(form.get("amount"));
    const response = await fetch("/api/sales", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({ role, reference, customer:form.get("customer"), project:form.get("project"), description:form.get("description"), amount, richard:split[0], anastasia:split[1], jeanClaude:split[2] }) });
    const result = await response.json(); setMessage(result.message ?? result.error); if (response.ok) { event.currentTarget.reset(); await refreshDashboard(); }
  }
  async function submitExpense(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!canSubmitExpense) return;
    const form = new FormData(event.currentTarget);
    const reference = String(form.get("reference")).trim().toUpperCase();
    const amount = Number(form.get("amount"));
    const allocation = String(form.get("allocation"));
    const response = await fetch("/api/expenses", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({ role, reference, description:form.get("description"), category:form.get("category"), allocation, amount }) });
    const result = await response.json(); setMessage(result.message ?? result.error); if (response.ok) { event.currentTarget.reset(); await refreshDashboard(); }
  }
  return <main className="shell">
    <header className="topbar"><div className="brand"><div className="mark">F</div><div><h1>Friends Included Finance</h1><p className="muted">Financial operations · YOUR NAME</p></div></div><label className="role">Demonstration role <select value={role} onChange={(e) => setRole(e.target.value as Employee)}>{employees.map((name)=><option key={name}>{name}</option>)}</select></label></header>
    <div className="notice">The dashboard calculates from saved data. Telegram and Google Sheets will be connected next.</div>
    <section className="metrics"><Metric title="Project A result" value={`€${(dashboard?.projectA.result ?? 0).toFixed(2)}`} note="Live calculation"/><Metric title="Project B result" value={`€${(dashboard?.projectB.result ?? 0).toFixed(2)}`} note="Live calculation"/><Metric title="Company result" value={`€${(dashboard?.company ?? 0).toFixed(2)}`} note="Live calculation"/></section>
    <section className="grid"><div className="panel"><h2>Transactions requiring attention</h2>{records.map((item)=><div className="row" key={item.reference}><div><b>{item.reference} · {item.kind}</b><small>{item.title} · €{item.amount.toFixed(2)}</small></div><span className={`badge ${item.status === "Pending approval" ? "pending" : item.status === "Awaiting allocation" ? "allocation" : "approved"}`}>{item.status}</span></div>)}</div><div className="panel"><h2>Commission earned</h2><div className="row"><b>Richard</b><b>€{(dashboard?.commission.Richard ?? 0).toFixed(2)}</b></div><div className="row"><b>Anastasia</b><b>€{(dashboard?.commission.Anastasia ?? 0).toFixed(2)}</b></div><div className="row"><b>Jean-Claude</b><b>€{(dashboard?.commission["Jean-Claude"] ?? 0).toFixed(2)}</b></div><p className="help">Commissions appear here only after Svetlana approves a sale.</p></div></section>
    <section className="forms"><div className="panel"><h2>Submit a sale</h2><form className="form" onSubmit={submitSale}><label>Reference<input name="reference" placeholder="S01" required disabled={!canSubmitSale}/></label><label>Customer<input name="customer" required disabled={!canSubmitSale}/></label><label>Project<select name="project" disabled={!canSubmitSale}><option>A</option><option>B</option></select></label><label>Description<textarea name="description" required disabled={!canSubmitSale}/></label><label>Amount (€)<input type="number" min="0.01" step="0.01" name="amount" required disabled={!canSubmitSale}/></label><label>Commission split: Richard / Anastasia / Jean-Claude<div className="split">{split.map((value,index)=><input key={index} type="number" min="0" max="100" value={value} disabled={!canSubmitSale} onChange={(e)=>{const next=[...split];next[index]=Number(e.target.value);setSplit(next);}}/>)}</div></label><p className="help">{splitValid ? "Split totals 100%." : "Split must total exactly 100%."}</p><button className="primary" disabled={!canSubmitSale || !splitValid}>Submit sale</button>{!canSubmitSale && <p className="help">Only salespeople can submit sales.</p>}</form></div>
    <div className="panel"><h2>Submit an expense</h2><form className="form" onSubmit={submitExpense}><label>Reference<input name="reference" placeholder="E01" required disabled={!canSubmitExpense}/></label><label>Description<textarea name="description" required disabled={!canSubmitExpense}/></label><label>Category<select name="category" disabled={!canSubmitExpense}><option>Materials</option><option>Travel</option><option>Other</option></select></label><label>Amount (€)<input type="number" min="0.01" step="0.01" name="amount" required disabled={!canSubmitExpense}/></label><label>Proposed allocation<select name="allocation" disabled={!canSubmitExpense}><option>A</option><option>B</option><option>Company overhead</option></select></label><button className="primary" disabled={!canSubmitExpense}>Submit expense</button>{!canSubmitExpense && <p className="help">Only Kevin can submit expenses.</p>}</form></div></section>
    {message && <p className="notice" role="status">{message}</p>}
    <footer className="links"><a href="#">Telegram bot — add after setup</a><a href="#">Google Sheet — add after setup</a><a href="#">GitHub repository — add after setup</a></footer>
  </main>;
}
function Metric({title,value,note}:{title:string;value:string;note:string}) { return <article className="metric"><span>{title}</span><strong>{value}</strong><em>{note}</em></article>; }
