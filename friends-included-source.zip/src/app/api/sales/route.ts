import { NextResponse } from "next/server";
import { canCreateSale, validateSplit, type Employee } from "@/lib/domain";
import { supabaseServer } from "@/lib/supabase-server";

export async function POST(request: Request) {
  try {
    const input = await request.json();
    const role = input.role as Employee;
    const amount = Number(input.amount);
    const split = [Number(input.richard), Number(input.anastasia), Number(input.jeanClaude)];
    if (!canCreateSale(role)) return NextResponse.json({ error: "Only salespeople can submit sales." }, { status: 403 });
    if (!/^S\d+$/i.test(input.reference ?? "") || !input.customer?.trim() || !input.description?.trim() || !["A", "B"].includes(input.project) || amount <= 0 || !validateSplit(split)) return NextResponse.json({ error: "Complete all fields. Sale references use S01 format, amount must be positive, and split must equal 100%." }, { status: 400 });
    const db = supabaseServer();
    const { data: employee, error: employeeError } = await db.from("employees").select("id").eq("name", role).single();
    if (employeeError) throw employeeError;
    const { error } = await db.from("sales").insert({ reference: input.reference.trim().toUpperCase(), salesperson_id: employee.id, customer: input.customer.trim(), project: input.project, description: input.description.trim(), amount, proposed_richard: split[0], proposed_anastasia: split[1], proposed_jean_claude: split[2] });
    if (error?.code === "23505") return NextResponse.json({ error: "That reference already exists." }, { status: 409 });
    if (error) throw error;
    return NextResponse.json({ ok: true, message: `${input.reference.toUpperCase()} saved as Pending approval.` });
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "Could not save sale." }, { status: 500 }); }
}

