import { NextResponse } from "next/server";
import { canCreateExpense, type Employee } from "@/lib/domain";
import { supabaseServer } from "@/lib/supabase-server";

export async function POST(request: Request) {
  try {
    const input = await request.json(); const role = input.role as Employee; const amount = Number(input.amount);
    if (!canCreateExpense(role)) return NextResponse.json({ error: "Only Kevin can submit expenses." }, { status: 403 });
    if (!/^E\d+$/i.test(input.reference ?? "") || !input.description?.trim() || !["Materials", "Travel", "Other"].includes(input.category) || !["A", "B", "Company overhead"].includes(input.allocation) || amount <= 0) return NextResponse.json({ error: "Complete all fields. Expense references use E01 format and amount must be positive." }, { status: 400 });
    const db = supabaseServer(); const { data: employee, error: employeeError } = await db.from("employees").select("id").eq("name", "Kevin").single(); if (employeeError) throw employeeError;
    const status = input.allocation === "Company overhead" ? "company_overhead" : "awaiting_allocation";
    const final_allocation = input.allocation === "Company overhead" ? "Company overhead" : null;
    const { error } = await db.from("expenses").insert({ reference: input.reference.trim().toUpperCase(), reporter_id: employee.id, description: input.description.trim(), category: input.category, amount, proposed_allocation: input.allocation, final_allocation, status });
    if (error?.code === "23505") return NextResponse.json({ error: "That reference already exists." }, { status: 409 }); if (error) throw error;
    return NextResponse.json({ ok: true, message: `${input.reference.toUpperCase()} saved.` });
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "Could not save expense." }, { status: 500 }); }
}
