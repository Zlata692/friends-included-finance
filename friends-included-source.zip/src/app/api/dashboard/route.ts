import { NextResponse } from "next/server";
import { supabaseServer } from "@/lib/supabase-server";

const money = (value: number) => Math.round(value * 100) / 100;
export async function GET() {
  try {
    const db = supabaseServer();
    const [{ data: sales, error: saleError }, { data: expenses, error: expenseError }] = await Promise.all([
      db.from("sales").select("reference,customer,project,amount,status,richard_commission,anastasia_commission,jean_claude_commission,submitted_at").order("submitted_at", { ascending: false }),
      db.from("expenses").select("reference,description,amount,status,final_allocation,submitted_at").order("submitted_at", { ascending: false }),
    ]);
    if (saleError) throw saleError; if (expenseError) throw expenseError;
    const approved = (sales ?? []).filter((sale) => sale.status === "approved");
    const project = (code: "A" | "B") => { const relevant = approved.filter((sale) => sale.project === code); const income = relevant.reduce((sum, sale) => sum + Number(sale.amount), 0); const commissions = relevant.reduce((sum, sale) => sum + Number(sale.richard_commission) + Number(sale.anastasia_commission) + Number(sale.jean_claude_commission), 0); const costs = (expenses ?? []).filter((expense) => expense.status === "allocated" && expense.final_allocation === code).reduce((sum, expense) => sum + Number(expense.amount), 0); return { income: money(income), commissions: money(commissions), expenses: money(costs), result: money(income - commissions - costs) }; };
    const totalSales = approved.reduce((sum, sale) => sum + Number(sale.amount), 0); const commissions = approved.reduce((sum, sale) => sum + Number(sale.richard_commission) + Number(sale.anastasia_commission) + Number(sale.jean_claude_commission), 0); const totalExpenses = (expenses ?? []).reduce((sum, expense) => sum + Number(expense.amount), 0);
    const records = [...(sales ?? []).map((sale) => ({ reference:sale.reference, kind:"Sale", title:`${sale.customer} · Project ${sale.project}`, amount:Number(sale.amount), status:sale.status === "approved" ? "Approved" : "Pending approval", createdAt:sale.submitted_at })), ...(expenses ?? []).map((expense) => ({ reference:expense.reference, kind:"Expense", title:expense.description, amount:Number(expense.amount), status:expense.status === "awaiting_allocation" ? "Awaiting allocation" : expense.status === "allocated" ? "Allocated" : "Company overhead", createdAt:expense.submitted_at }))].sort((a,b) => b.createdAt.localeCompare(a.createdAt));
    return NextResponse.json({ projectA:project("A"), projectB:project("B"), company:money(totalSales - commissions - totalExpenses), commission:{ Richard:money(approved.reduce((sum,sale)=>sum+Number(sale.richard_commission),0)), Anastasia:money(approved.reduce((sum,sale)=>sum+Number(sale.anastasia_commission),0)), "Jean-Claude":money(approved.reduce((sum,sale)=>sum+Number(sale.jean_claude_commission),0)) }, records });
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "Could not load dashboard." }, { status: 500 }); }
}
