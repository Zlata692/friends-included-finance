import { NextResponse } from "next/server";
import { canApprove, commissionAmounts, validateSplit, type Employee } from "@/lib/domain";
import { supabaseServer } from "@/lib/supabase-server";

export async function POST(request: Request) {
  try {
    const input = await request.json();
    if (!canApprove(input.role as Employee)) return NextResponse.json({ error: "Only Svetlana can approve transactions." }, { status: 403 });
    const db = supabaseServer();
    if (input.kind === "sale") {
      const { data: sale, error } = await db.from("sales").select("*").eq("reference", input.reference).single();
      if (error || !sale) return NextResponse.json({ error: "Sale not found." }, { status: 404 });
      if (sale.status === "approved") return NextResponse.json({ error: "This sale is already approved; totals were not changed." }, { status: 409 });
      const split: [number,number,number] = [Number(input.richard ?? sale.proposed_richard), Number(input.anastasia ?? sale.proposed_anastasia), Number(input.jeanClaude ?? sale.proposed_jean_claude)];
      if (!validateSplit(split)) return NextResponse.json({ error: "Final commission split must equal exactly 100%." }, { status: 400 });
      const commission = commissionAmounts(Number(sale.amount), split);
      const { error: updateError } = await db.from("sales").update({ status:"approved", approved_richard:split[0], approved_anastasia:split[1], approved_jean_claude:split[2], richard_commission:commission.values[0], anastasia_commission:commission.values[1], jean_claude_commission:commission.values[2], approved_at:new Date().toISOString(), sheets_sync_status:"pending", notification_status:"pending" }).eq("id", sale.id).eq("status", "pending_approval");
      if (updateError) throw updateError;
      return NextResponse.json({ ok:true, message:`${sale.reference} approved. Commission pool: €${commission.pool.toFixed(2)}.` });
    }
    if (input.kind === "expense") {
      const { data: expense, error } = await db.from("expenses").select("*").eq("reference", input.reference).single();
      if (error || !expense) return NextResponse.json({ error: "Expense not found." }, { status: 404 });
      if (expense.status !== "awaiting_allocation") return NextResponse.json({ error: "This expense is already allocated; totals were not changed." }, { status: 409 });
      if (!["A", "B", "Company overhead"].includes(input.allocation)) return NextResponse.json({ error: "Choose A, B, or Company overhead." }, { status: 400 });
      const { error: updateError } = await db.from("expenses").update({ status:"allocated", final_allocation:input.allocation, allocated_at:new Date().toISOString(), sheets_sync_status:"pending", notification_status:"pending" }).eq("id", expense.id).eq("status", "awaiting_allocation");
      if (updateError) throw updateError;
      return NextResponse.json({ ok:true, message:`${expense.reference} allocated to ${input.allocation}.` });
    }
    return NextResponse.json({ error:"Unknown transaction type." }, { status:400 });
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "Could not approve transaction." }, { status: 500 }); }
}
