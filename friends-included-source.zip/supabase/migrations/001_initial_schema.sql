create type employee_role as enum ('manager', 'salesperson', 'expense_reporter');
create type project_code as enum ('A', 'B');
create type sale_status as enum ('pending_approval', 'approved');
create type expense_status as enum ('awaiting_allocation', 'allocated', 'company_overhead');

create table employees (
  id uuid primary key default gen_random_uuid(),
  name text unique not null,
  role employee_role not null,
  telegram_user_id bigint unique,
  linked_telegram_chat_id bigint,
  created_at timestamptz not null default now()
);

create table sales (
  id uuid primary key default gen_random_uuid(), reference text unique not null,
  salesperson_id uuid not null references employees(id), customer text not null,
  project project_code not null, description text not null, amount numeric(12,2) not null check (amount > 0),
  proposed_richard numeric(5,2) not null, proposed_anastasia numeric(5,2) not null, proposed_jean_claude numeric(5,2) not null,
  approved_richard numeric(5,2), approved_anastasia numeric(5,2), approved_jean_claude numeric(5,2),
  richard_commission numeric(12,2) not null default 0, anastasia_commission numeric(12,2) not null default 0, jean_claude_commission numeric(12,2) not null default 0,
  status sale_status not null default 'pending_approval', originating_chat_id bigint, submitted_at timestamptz not null default now(), approved_at timestamptz,
  sheets_sync_status text not null default 'pending', notification_status text not null default 'not_required'
);

create table expenses (
  id uuid primary key default gen_random_uuid(), reference text unique not null,
  reporter_id uuid not null references employees(id), description text not null, category text not null check (category in ('Materials','Travel','Other')),
  amount numeric(12,2) not null check (amount > 0), proposed_allocation text not null check (proposed_allocation in ('A','B','Company overhead')),
  final_allocation text check (final_allocation in ('A','B','Company overhead')), status expense_status not null,
  originating_chat_id bigint, submitted_at timestamptz not null default now(), allocated_at timestamptz,
  sheets_sync_status text not null default 'pending', notification_status text not null default 'not_required'
);

insert into employees (name, role) values
  ('Svetlana', 'manager'), ('Richard', 'salesperson'), ('Anastasia', 'salesperson'), ('Jean-Claude', 'salesperson'), ('Kevin', 'expense_reporter');
